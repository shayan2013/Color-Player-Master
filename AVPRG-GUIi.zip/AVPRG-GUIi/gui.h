#ifndef GUI_H
#define GUI_H

#include <QMainWindow>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include "color.h"

namespace Ui {
class Gui;
}

class Gui : public QMainWindow
{
    Q_OBJECT

public:
    explicit Gui(QWidget *parent = 0);
    ~Gui();


private slots:
    void on_startButton_clicked();
    void on_stopButton_clicked();

    void on_redComboBoxTone_activated(const QString &arg1);

    void on_redComboBoxDelay_activated(const QString &arg1);

    void on_redComboBoxOctave_activated(int index);

    void on_blueComboBoxTone_activated(const QString &arg1);

    void on_blueComboBoxOctave_activated(int index);

    void on_blueComboBoxDelay_activated(const QString &arg1);

    void on_greenComboBoxTone_activated(const QString &arg1);

    void on_greenComboBoxOctave_activated(int index);

    void on_greenComboBoxDelay_activated(const QString &arg1);

    void on_yellowComboBoxTone_activated(const QString &arg1);

    void on_yellowComboBoxOctave_activated(int index);

    void on_yellowComboBoxDelay_activated(const QString &arg1);

private:
    Ui::Gui *ui;

    cv::VideoCapture capWebcame;
    cv::Mat imgOriginal;
    cv::Mat rgbOriginal;
    cv::Mat imgHSV;
    QImage qimgOriginal;

    QTimer* tmrTimer;

    cv::Mat thresholdR, thresholdB, thresholdG, thresholdY;
    int tR, tB, tG, tY;
    int dR, dB, dG, dY;
    int fR, fB, fG, fY;
    int oR, oB, oG, oY;
    int freq;
    int delay;
    int tone;
    int octave;


 public slots:
    void processFrame();
    void removeAndFill(cv::Mat &tresh);
    double momentsArea(cv::Mat treshhold);
    int getFreq();
    int getDelay();
    void setFreq(int freq);
    void setDelay(int delay);
    void setOR(int oR);
    int getOR();
    int freqMaker(int tone, int octave);




};

#endif // GUI_H
