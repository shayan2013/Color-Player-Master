#include "gui.h"
#include "ui_gui.h"
#include "color.h"
#include <QtCore>

Gui::Gui(QWidget *parent):QMainWindow(parent),ui(new Ui::Gui)
{
    ui->setupUi(this);
   /* capWebcame.open(0);
    if(capWebcame.isOpened() == false){
        return;
    }
    tmrTimer = new QTimer(this);
    connect(tmrTimer, SIGNAL(timeout()), this, SLOT(processFrame()));
    tmrTimer->start(20);*/

}


Gui::~Gui()
{
    delete ui;
}


int Gui::getFreq() {
    return Gui::freq;
}

int Gui::getDelay() {
    return Gui::delay;
}

void Gui::setFreq(int freq) {
    Gui::freq = freq;
}

void Gui::setDelay(int delay) {
    Gui::delay = delay;
}

void Gui::setOR(int oR) {
    Gui::oR = oR;
}

int Gui::getOR() {
    return Gui::oR;
}

void Gui::removeAndFill (cv::Mat &thresh) {
    //remove small objects from the foreground
    cv::erode(thresh, thresh, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));
    cv::dilate(thresh, thresh, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));

    //fill small holes in the foreground
    cv::dilate(thresh,thresh, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));
    cv::erode(thresh, thresh, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));
}

double Gui::momentsArea (cv::Mat threshold){
    cv::Moments oMoments = moments(threshold);
    double dArea = oMoments.m00;
    return dArea;
}



int Gui::freqMaker(int tone, int octave) {
    int freq;
    switch (tone) {
    case(1) :
        if (octave == 1)
            freq = 131;
        else if (octave == 2)
            freq = 262;
        else if (octave == 3)
            freq = 523;
        break;
    case(2) :
        if (octave == 1)
            freq = 139;
        else if (octave == 2)
            freq = 277;
        else if (octave == 3)
            freq = 554;
        break;
    case(3) :
        if (octave == 1)
            freq = 147;
        else if (octave == 2)
            freq = 294;
        else if (octave == 3)
            freq = 587;
        break;
    case(4) :
        if (octave == 1)
            freq = 156;
        else if (octave == 2)
            freq = 311;
        else if (octave == 3)
            freq = 622;
        break;
    case(5) :
        if (octave == 1)
            freq = 165;
        else if (octave == 2)
            freq = 330;
        else if (octave == 3)
            freq = 659;
        break;
    case(6) :
        if (octave == 1)
            freq = 175;
        else if (octave == 2)
            freq = 349;
        else if (octave == 3)
            freq = 698;
        break;
    case(7) :
        if (octave == 1)
            freq = 185;
        else if (octave == 2)
            freq = 370;
        else if (octave == 3)
            freq = 740;
        break;
    case(8) :
        if (octave == 1)
            freq = 196;
        else if (octave == 2)
            freq = 392;
        else if (octave == 3)
            freq = 784;
        break;
    case(9) :
        if (octave == 1)
            freq = 208;
        else if (octave == 2)
            freq = 415;
        else if (octave == 3)
            freq = 830;
        break;
    case(10) :
        if (octave == 1)
            freq = 220;
        else if (octave == 2)
            freq = 440;
        else if (octave == 3)
            freq = 880;
        break;
    case(11) :
        if (octave == 1)
            freq = 233;
        else if (octave == 2)
            freq = 466;
        else if (octave == 3)
            freq = 932;
        break;
    case(12) :
        if (octave == 1)
            freq = 247;
        else if (octave == 2)
            freq = 494;
        else if (octave == 3)
            freq = 988;
        break;
    default:
        break;
    }
    return freq;
}
//***********************RED**************************//
void Gui::on_redComboBoxDelay_activated(const QString &arg1)
{
    if(arg1=="ganz"){
        dR=3200;
    }
    if(arg1=="halb"){
        dR=1600;
    }
    if(arg1=="viertel"){
        dR=800;
    }
    if(arg1=="achtel"){
        dR=400;
    }
    if(arg1=="sechzentel"){
        dR=200;
    }
}

void Gui::on_redComboBoxTone_activated(const QString &arg1)
{

    if(arg1=="c"){
       tR = 1;
    }
    if(arg1=="c#"){
       tR = 2;
    }
    if(arg1=="d"){
       tR = 3;
    }
    if(arg1=="d#"){
       tR = 4;
    }
    if(arg1=="e"){
       tR = 5;
    }
    if(arg1=="f"){
       tR = 6;
    }
    if(arg1=="f#"){
       tR = 7;
    }
    if(arg1=="g"){
       tR = 8;
    }
    if(arg1=="g#"){
       tR = 9;
    }
    if(arg1=="a"){
       tR = 10;
    }
    if(arg1=="a#"){
       tR = 11;
    }
    if(arg1=="b"){
       tR = 12;
    }
}


void Gui::on_redComboBoxOctave_activated(int index)
{
    oR = index;
}



//***********************BLUE**************************//

void Gui::on_blueComboBoxTone_activated(const QString &arg1)
{
    if(arg1=="c"){
       tB = 1;
    }
    if(arg1=="c#"){
       tB = 2;
    }
    if(arg1=="d"){
       tB = 3;
    }
    if(arg1=="d#"){
       tB = 4;
    }
    if(arg1=="e"){
       tB = 5;
    }
    if(arg1=="f"){
       tB = 6;
    }
    if(arg1=="f#"){
       tB = 7;
    }
    if(arg1=="g"){
       tB = 8;
    }
    if(arg1=="g#"){
       tB = 9;
    }
    if(arg1=="a"){
       tB = 10;
    }
    if(arg1=="a#"){
       tB = 11;
    }
    if(arg1=="b"){
       tB = 12;
    }
}

void Gui::on_blueComboBoxOctave_activated(int index)
{
     oB = index;
}

void Gui::on_blueComboBoxDelay_activated(const QString &arg1)
{
    if(arg1=="ganz"){
        dB=3200;
    }
    if(arg1=="halb"){
        dB=1600;
    }
    if(arg1=="viertel"){
        dB=800;
    }
    if(arg1=="achtel"){
        dB=400;
    }
    if(arg1=="sechzentel"){
        dB=200;
    }
}


//***********************GREEN**************************//
void Gui::on_greenComboBoxTone_activated(const QString &arg1)
{
    if(arg1=="c"){
       tG = 1;
    }
    if(arg1=="c#"){
       tG = 2;
    }
    if(arg1=="d"){
       tG = 3;
    }
    if(arg1=="d#"){
       tG = 4;
    }
    if(arg1=="e"){
       tG = 5;
    }
    if(arg1=="f"){
       tG = 6;
    }
    if(arg1=="f#"){
       tG = 7;
    }
    if(arg1=="g"){
       tG = 8;
    }
    if(arg1=="g#"){
       tG = 9;
    }
    if(arg1=="a"){
       tG = 10;
    }
    if(arg1=="a#"){
       tG = 11;
    }
    if(arg1=="b"){
       tG = 12;
    }
}

void Gui::on_greenComboBoxOctave_activated(int index)
{
     oG = index;
}

void Gui::on_greenComboBoxDelay_activated(const QString &arg1)
{
    if(arg1=="ganz"){
        dG=3200;
    }
    if(arg1=="halb"){
        dG=1600;
    }
    if(arg1=="viertel"){
        dG=800;
    }
    if(arg1=="achtel"){
        dG=400;
    }
    if(arg1=="sechzentel"){
        dG=200;
    }
}

//***********************YELLOW**************************//

void Gui::on_yellowComboBoxTone_activated(const QString &arg1)
{
    if(arg1=="c"){
       tY = 1;
    }
    if(arg1=="c#"){
       tY = 2;
    }
    if(arg1=="d"){
       tY = 3;
    }
    if(arg1=="d#"){
       tY = 4;
    }
    if(arg1=="e"){
       tY = 5;
    }
    if(arg1=="f"){
       tY = 6;
    }
    if(arg1=="f#"){
       tY = 7;
    }
    if(arg1=="g"){
       tY = 8;
    }
    if(arg1=="g#"){
       tY = 9;
    }
    if(arg1=="a"){
       tY = 10;
    }
    if(arg1=="a#"){
       tY = 11;
    }
    if(arg1=="b"){
       tY = 12;
    }
}

void Gui::on_yellowComboBoxOctave_activated(int index)
{
     oY = index;
}

void Gui::on_yellowComboBoxDelay_activated(const QString &arg1)
{
    if(arg1=="ganz"){
        dY=3200;
    }
    if(arg1=="halb"){
        dY=1600;
    }
    if(arg1=="viertel"){
        dY=800;
    }
    if(arg1=="achtel"){
        dY=400;
    }
    if(arg1=="sechzentel"){
        dY=200;
    }
}

//***********************BUTTON**************************//

void Gui::on_startButton_clicked()
{

    capWebcame.open(0);
    if(capWebcame.isOpened() == false){
        return;
    }
    tmrTimer = new QTimer(this);
    connect(tmrTimer, SIGNAL(timeout()), this, SLOT(processFrame()));
    tmrTimer->start(20);

    if(tmrTimer->isActive() == false){
       tmrTimer->start(20);
    }

}

void Gui::on_stopButton_clicked()
{
    if(tmrTimer->isActive() == true){
        tmrTimer->stop();
    }
}



//***************************PROCESS************************//

void Gui::processFrame(){
    capWebcame.read(imgOriginal);
    if(imgOriginal.empty()==true) return;

    //**** Color Detection ***//

     //Convert the captured frame from BGR to HSV
      cv::cvtColor(imgOriginal, imgHSV, CV_BGR2HSV);

       //Red Color
       cv::inRange(imgHSV, cv::Scalar(131, 113, 40), cv::Scalar(190, 255, 255), thresholdR);
       removeAndFill(thresholdR);

        //Blue Color
            cv::inRange(imgHSV, cv::Scalar(87, 116, 0), cv::Scalar(145, 255, 255), thresholdB);
            removeAndFill(thresholdB);

            //Green Color
            cv::inRange(imgHSV, cv::Scalar(38, 88, 0), cv::Scalar(97, 198, 255), thresholdG);
            removeAndFill(thresholdG);

            //Yellow Color
            cv::inRange(imgHSV, cv::Scalar(0, 43, 255),cv::Scalar(37, 165, 255), thresholdY);
            removeAndFill(thresholdY);


            // if the darea <= 10000, consider that there are no object in the image and it's because of the noise, the area is not zero
                    if (momentsArea(thresholdR) > 1000000)
                    {

                            //setDelay(delay);

                            Beep(freqMaker(tR,oR),dR);
                    }

                    if (momentsArea(thresholdB) > 1000000)
                    {

                            Beep(freqMaker(tB,oB),dB);
                        }

                    if (momentsArea(thresholdG) > 1000000)
                    {

                            Beep(freqMaker(tG,oG),dG);
                        }

                    if (momentsArea(thresholdY) > 1000000)
                    {

                           Beep(freqMaker(tY,oY),dY);
                        }





   cv::cvtColor(imgOriginal, rgbOriginal, CV_BGR2RGB);
   QImage qimgOriginal((uchar*)rgbOriginal.data, rgbOriginal.cols, rgbOriginal.rows, rgbOriginal.step, QImage::Format_RGB888);
   ui->cameraFrame ->setPixmap(QPixmap::fromImage(qimgOriginal));
    //QImage qimgOriginal((uchar*)thresholdR.data, thresholdR.cols, thresholdR.rows, thresholdR.step, QImage::Format_Indexed8);
    //ui->cameraFrame ->setPixmap(QPixmap::fromImage(qimgOriginal));
}


